# `String.length (to_ocaml (Rep(0,Some n,r)) ≡ n * String.length (to_ocaml (Opt r))`
'''ocaml
let rec to_ocaml r = 
  let rec to_ocaml_helper = function
    | Rep (l, h, r)-> ocaml_rep l h r ...
    | Opt t-> (match t with
    | Choice lst -> "\\("^ (to_ocaml_choice lst) ^ "\\)" ^ "?"
    | Concat lst -> "\\("^ (to_ocaml_concat lst) ^ "\\)" ^ "?"
    | Rep (l, h, r) -> "\\("^ (ocaml_rep l h r) ^ "\\)" ^ "?"
    | x -> (to_ocaml x) ^ "?" )
and ocaml_rep l h r = (match (l,h) with
    | (0, None) -> (precedance r "*")
    | (l, None) -> (precedance r "")  ^ (ocaml_rep (l-1) h r) (*to get to base case*)
    | (0, Some 0) -> ""
    | (l, Some upper_lim) when upper_lim < 0 -> failwith "invalid repetition count(s)"
    | (0, Some upper_lim) -> (precedance r "") ^ "?" ^ (ocaml_rep 0 (Some (upper_lim -1)) r) (*to match one instance of repetition*)
    | (l, Some upper_lim) -> (precedance r "") ^ (ocaml_rep (l-1) (Some (upper_lim -1)) r) )
and precedance r ch = (match r with
  | Choice lst -> "\\("^ (to_ocaml_choice lst) ^ "\\)" ^ ch
  | Concat lst -> "\\("^ (to_ocaml_concat lst) ^ "\\)" ^ ch
  | Rep (l, h, r) -> "\\("^ (ocaml_rep l h r) ^ "\\)" ^ ch
  | x -> (to_ocaml x) ^ ch
'''

### Property
P(n): ∀ r: RE.t, String.length (to_ocaml (Rep(0, Some n, r)) ≡ n * String.length (to_ocaml (Opt r))

### Base Case
P(0): String.length (to_ocaml (Rep(0, Some 0, r)) ≡ 0 * String.length (to_ocaml (Opt r))
+ `String.length (to_ocaml (Rep(0, Some 0, r)) ≡ String.length ""` **[eval of `to_ocaml`]**
+ `String.length "" ≡ 0` **[eval `String.length`]**
+ `0 ≡ 0 * String.length (to_ocaml (Opt r))` **[arithmetic]**

### Inductive Case
IH: String.length (to_ocaml (Rep(0, Some n, r)) ≡ n * String.length (to_ocaml (Opt r))
IC: String.length (to_ocaml (Rep(0, Some (n + 1,r))) ≡ (n + 1) * String.length (to_ocaml (Opt r))
+ `String.length (to_ocaml (Rep(0, Some (n + 1),r)) ≡ String.length (ocaml_rep 0 Some (n + 1) r)` **[eval of `to_ocaml`]**
+ `≡ String.length (precedance r "") ^ "?" ^ (ocaml_rep 0 (Some ((n+1) -1)) r)` **[eval of `ocaml_rep`]**
+ `≡ String.length (precedance r "") ^ "?" ^ (ocaml_rep 0 (Some ((n+1) -1)) r) ≡ (precedance r "") ^ "?" ^ (ocaml_rep 0 (Some n r))` **[arithmetic]**
+ `≡ String.length ((to_ocaml r) ^ "") ^ "?" ^ (ocaml_rep 0 (Some n r)) ` **[eval of precedance]**
+ `≡ String.length ((to_ocaml Opt r) ^ (ocaml_rep 0 (Some n r)) ` **[b/c Opt and precadence are equivalent]**
+ `≡ String.length ((to_ocaml Opt r) + String.length (ocaml_rep 0 (Some n r))` **[Property of String.length]**
+ `≡ String.length ((to_ocaml Opt r) + String.length (to_ocaml (Rep (0, Some n, r))` **[reverse eval of to_ocaml_rep]**
+ `≡ String.length ((to_ocaml Opt r) + n * String.length (to_ocaml (Opt r))` **[IH]**
+ `≡(n + 1) * String.length (to_ocaml (Opt r))` **[arithmetic]**
QED