(* Turning a string into a regular expression *)

type cclass = Wild | Word | NotWord | Digit | NotDigit | Space | NotSpace | EoL | StL
type t = Choice of t list
| Concat of t list
| Star of t
| Plus of t
| Char of char
| Bracket of string
| Rep of int * int option * t
| Opt of t
| Class of cclass


(* Tokens (substrings that make up regular expressions) *)
type tok = LP | RP | ST | PLUS | Q | REP of int option * int option | U | DOT | Ch of char | BR of string | CL of cclass

(* turn a string into a list of regex tokens *)
let rec tokenize st i =
  if String.length st = i then []
  else if st.[i] = '[' then read_bracket st (i+1)
  else if st.[i] = '\\' then read_escape st (i+1)
  else (match st.[i] with
    '*' -> ST | '?' -> Q | '.' -> DOT |
    '^' -> CL StL | '$' -> CL EoL | c -> Ch c)::(tokenize st (i+1))
and read_escape st i =
  if String.length st = i then failwith "trailing backslash"
  else if st.[i] = '{' then read_rep st (i+1)
  else (match st.[i] with '(' -> [LP]
    | ')' -> [RP]
    | '|' -> [U]
    | 'W' -> [CL NotWord]
    | 'w' -> [CL Word]
    | 'D' -> [CL NotDigit]
    | 'd' -> [CL Digit]
    | 'S' -> [CL NotSpace]
    | 's' -> [CL Space]
    | '+' -> [PLUS]
    | '.' | '[' | ']' | '*' | '?' | '$' | '^' -> [Ch st.[i]]
    | c -> [Ch '\\'; Ch c]) @ (tokenize st (i+1))
and read_bracket st i =
  if String.length st = i then failwith "brackets not balanced"
  else
    let si = if st.[i] = ']' then i+1 else i in
    let sn = (match String.index_from_opt st si ']' with
    | None -> failwith "brackets not balanced"
    | Some n -> n)
    in (BR (String.sub st i (sn-i)))::tokenize st (sn+1)
and read_rep st i =
  if String.length st = i then failwith "braces not balanced"
  else
    let sn = (match String.index_from_opt st i '}' with
    | None -> failwith "braces not balanced"
    | Some n -> if st.[n-1] = '\\' then n-1 else failwith "invalid repetition count(s)") in
    let rs = String.sub st i (sn-i) in
    let (mn,mx) = match String.split_on_char ',' rs with
    | ""::[""] -> (None, None)
    | ""::[h] -> (None, Some (int_of_string h))
    | l::[""] -> (Some (int_of_string l), None)
    | l::[h] -> (Some (int_of_string l), Some (int_of_string h))
    | [mm] -> (Some (int_of_string mm), Some (int_of_string mm))
    | _ -> failwith "invalid repetition count(s)"
    in (REP (mn,mx))::tokenize st (sn+2)


(* parse a list of tokens into a regexp *)
(* each function takes a list of tokens, tries to parse a kind of regex from the list,
  and returns the list of unused tokens *)
let rec
  (* parse a "Base" Case regexp: Empty, NullSet, Bracket, Wild, Class or Char *)
  parse_base_case token_list = match token_list with
  | [] -> failwith "empty token list"
  | (BR s)::tl -> ((Bracket s), tl)
  | DOT::tl -> (Class Wild,tl)
  | (CL c)::tl -> (Class c, tl)
  | LP::tl -> let (re,tl') = parse_regex tl in
    (match tl' with RP::tl'' -> (re,tl'')
    | _ -> failwith "parentheses not balanced")
  | (Ch c)::tl -> (Char c,tl)
  | _ -> failwith "unexpected token"
and
  parse_postfix token_list = (* parse a regex of the form r [postfix] *)
    let (re,tl) = parse_base_case token_list in
      match tl with
      | ST::tl' -> (Star re, tl')
      | PLUS::tl' -> (Plus re, tl')
      | Q::tl' -> (Opt re, tl')
      | (REP (None,h))::tl' -> (Rep (0,h,re), tl')
      | (REP (Some l, None))::tl' -> (Rep (l,None,re), tl')
      | (REP (Some l, Some h))::tl' -> if h >=l && l >= 0 then (Rep (l,Some h,re), tl') else failwith "invalid repetition count(s)"
      | _ -> (re, tl)
and
  term_helper tl rel = match tl with (* parse a "factor" in a regex of the form r1 r2 (r3 ...) *)
  | RP::tl' -> (Concat (List.rev rel),tl)
  | U::tl' -> (Concat (List.rev rel),tl)
  | [] -> (Concat (List.rev rel),[])
  | _ -> let (re_next,tl') = parse_postfix tl in
    term_helper tl' (re_next::rel)
and
  parse_terms tl = match parse_postfix tl with (* parse a regex in the form r1 r2 (r3...) *)
  | (t,RP::tl') -> (t, RP::tl')
  | (t,U::tl') -> (t, U::tl')
  | (t,[]) -> (t, [])
  | (t,tl')-> term_helper tl' [t]
and
  regex_helper tl rel = (* helper for parsing union of terms *)
    let (t_next,tl') = parse_terms tl in match tl' with
    | U::tl'' -> regex_helper tl'' (t_next::rel)
    | _ -> (Choice (List.rev (t_next::rel)), tl')
and parse_regex tl = match parse_terms tl with (* parse a regex *)
  | (t,U::tl') -> regex_helper tl' [t]
  | (t,tl') -> t,tl'

let rex_parse s =
  let tok_list = tokenize s 0 in
  match parse_regex tok_list with
  | (re,[]) -> re
  | _ -> failwith "parentheses not balanced"
