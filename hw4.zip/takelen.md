# `(lztake (length l) (lz_of_list l)) ≡ l`
```ocaml
let rec length = function [] -> 0
| _::t -> 1 + (length t)
```
```ocaml
let rec lztake n ll = match (n,ll) with
| (0,_) | (_,Nil) -> []
| (_,Lcons(h,t)) -> h::(lztake (n-1) (Lazy.force t))
```
```ocaml
let rec lz_of_list = function [] -> Nil
| h::t -> Lcons(h,lazy(lz_of_list t))
```

### Property
P(l): `(lztake (length l) (lz_of_list l)) ≡ l`

### Base Case
P([]): `(lztake (length []) (lz_of_list [])) ≡ []`
+ `(lztake (length []) (lz_of_list [])) ≡ (lztake (length []) Nil` **[eval of `lz_of_list`]**  
+ `(lztake (length []) Nil ≡ lztake 0 Nil` **[eval of `length`]**
+ `lztake 0 Nil ≡ []` **[eval of `lztake`]**

### Inductive Case
IH: ∀ l.`(lztake (length l) (lz_of_list l)) ≡ l` 
IC: ∀ l. `(lztake (length h :: l) (lz_of_list h :: l)) ≡ h :: l`
+ `(lztake (length h::l) (lz_of_list h::l)) ≡  lztake ((length l) + 1) (lz_of_list h::l)` : **[eval of `length`]**
+ ` ≡ lztake ((length l) + 1) (Lcons(h,lazy(lz_of_list l)))` **[eval of `lz_of_list`]**                                         
+ `≡ h::(lztake ((1 + (length l))-1) (Lazy.force (lazy(lz_of_list l)))` **[eval of `lz_take`]**
+ `≡ h::(lztake (length l)) (Lazy.force (lazy(lz_of_list l)))` **[arithmetic]**
+ `≡ h::(lztake (length l) (lz_of_list l))`  **[eval of Lazy.force]**
+ `≡ h::l` **[IH]**
QED