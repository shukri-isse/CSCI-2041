(* cGrep.ml -- func for camlgrep *)
open RE

type 'a lzlist  = Nil | Lcons of 'a * 'a lzlist Lazy.t

(* testing stuff *)
let rec lztake n ll = match (n,ll) with
| (0,_) | (_,Nil) -> []
| (_,Lcons(h,t)) -> h::(lztake (n-1) (Lazy.force t))

let rec lz_of_list = function [] -> Nil
| h::t -> Lcons(h,lazy(lz_of_list t))

(* don't call on an infinite list *)
let lzlength ll =
  let rec lzlen acc = function Nil -> acc
  | Lcons(_,t) -> lzlen (acc+1) (Lazy.force t)
in lzlen 0 ll

(* fill these in: *)

(* converts an RE.t regexp syntax tree to an ocaml-syntax regexp string *)
(* Converts Star, Plus, Opt, Concact, Choice, Bracket, & Rep into strings 
that the Str.regexp parser will understand. While taking into consideration the 
precedence postfix repetition operators Star, Plus, and Opt, Special cases such as 
Wild ".", StL "^", EoL "$", and the new cases (Digit/NotDigit, Space/NotSpace, and Word/NotWord)
as well as accounting for the bounded repition nccessary for constructor Rep and 
escaped characters are also take into consideration.*)
let rec to_ocaml r = 
  let rec to_ocaml_helper = function
  | Concat lst -> to_ocaml_concat lst
  | Star t-> (match t with 
    | Choice lst -> "\\("^ (to_ocaml_choice lst) ^ "\\)" ^ "*"
    | Concat lst -> "\\("^ (to_ocaml_concat lst) ^ "\\)" ^ "*"
    | Rep (l, h, r) -> "\\("^ (ocaml_rep l h r) ^ "\\)" ^ "*"
    | x -> (to_ocaml x) ^ "*" )
  | Plus t-> (match t with
    | Choice lst -> "\\("^ (to_ocaml_choice lst) ^ "\\)" ^ "+"
    | Concat lst -> "\\("^ (to_ocaml_concat lst) ^ "\\)" ^ "+"
    | Rep (l, h, r) -> "\\("^ (ocaml_rep l h r) ^ "\\)" ^ "+"
    | x -> (to_ocaml x) ^ "+" )
  | Char ch-> 
  let s = String.make 1 ch in
  (match ch with 
    '$' | '^' | '\\' | '*' | '+' | '?' | '.' | '[' | ']' -> "\\" ^ s
    | _ -> s)
  | Bracket str-> "[" ^ str ^ "]"
  | Rep (l, h, r)-> ocaml_rep l h r
  | Opt t-> (match t with
    | Choice lst -> "\\("^ (to_ocaml_choice lst) ^ "\\)" ^ "?"
    | Concat lst -> "\\("^ (to_ocaml_concat lst) ^ "\\)" ^ "?"
    | Rep (l, h, r) -> "\\("^ (ocaml_rep l h r) ^ "\\)" ^ "?"
    | x -> (to_ocaml x) ^ "?" )
  | Class c -> (match c with 
    | Wild -> "."
    | StL -> "^"
    | EoL -> "$"
    | Digit -> "[0-9]"
    | NotDigit -> "[^0-9]" (*negation*)
    | Space -> "[ \t]"
    | NotSpace -> "[^ \t]"
    | Word -> "[_0-9A-Za-z]"
    | NotWord -> "[^_0-9A-Za-z]" )
  | Choice t ->  to_ocaml_choice t
  in to_ocaml_helper r
  and ocaml_rep l h r = (match (l,h) with
    | (0, None) -> (precedance r "*")
    | (l, None) -> (precedance r "")  ^ (ocaml_rep (l-1) h r) (*to get to base case*)
    | (0, Some 0) -> ""
    | (l, Some upper_lim) when upper_lim < 0 -> failwith "invalid repetition count(s)"
    | (0, Some upper_lim) -> (precedance r "") ^ "?" ^ (ocaml_rep 0 (Some (upper_lim -1)) r) (*to match one instance of repetition*)
    | (l, Some upper_lim) -> (precedance r "") ^ (ocaml_rep (l-1) (Some (upper_lim -1)) r) )
  and to_ocaml_concat lst = match lst with
    | [] -> ""
    | (Choice l) :: t -> "\\(" ^ (to_ocaml (Choice l)) ^ "\\)" ^ (to_ocaml_concat t)
    | h::t -> (to_ocaml h) ^ (to_ocaml_concat t)
  and precedance r ch = (match r with
  | Choice lst -> "\\("^ (to_ocaml_choice lst) ^ "\\)" ^ ch
  | Concat lst -> "\\("^ (to_ocaml_concat lst) ^ "\\)" ^ ch
  | Rep (l, h, r) -> "\\("^ (ocaml_rep l h r) ^ "\\)" ^ ch
  | x -> (to_ocaml x) ^ ch)
  and to_ocaml_choice lst = (String.concat "\\|" (List.map to_ocaml lst))


(* Return a string lzlist with the lines of the in_channel ic *)
(* take as input an in_channel, and return a lazy list whose elements will eventually consist of all the lines in the file.*)
let rec lzlines ic =
  try (Lcons(input_line ic,lazy(lzlines ic))) with End_of_file -> Nil

(* return a string lzlist of elements in ll that match (ocaml regexp) re;
 * if includeNums is true, insert line numbers followed by ":" before matching elements
 * if invert is true, include elements that do NOT match re *)
let rec lzmatches re lnums invert ll = (*returns true if there's a sunstring of the regular expression re starting at index 1 that matches the regexp re*)
 let rec lzmatches_helper counter = 
   function Nil -> Nil
  | Lcons(h,t) -> if invert <> (try (Str.search_forward re h 0) >= 0 with Not_found -> false) then (*if invert != to result of try*)
        Lcons((if lnums then ((string_of_int counter)^":"^h) else h), lazy(lzmatches_helper (counter+1) (Lazy.force t))) (*both are true*)(* lnums false and inverts true*)
      else lzmatches_helper (counter + 1) (Lazy.force t) 
in lzmatches_helper 1 ll


(* open fname, convert to lzlist, print out lines matching the grep-syntax regexp string grepre *)
(* return true iff at least one line was printed to the terminal. *)
let printmatches grepre fname lnums invert = 
  (*convert the "grep regex" s into an ocaml Str.regexp by calling to_ocaml*)
  (*open the file f for reading (or use stdin if f is "-")*)
  (*use lzlines and lzmatches to get a string lzlist of lines to print out, print them to the standard output*)
  (*close file*)
  (*return true if at least one matching line was found, and false otherwise*)
  let s = to_ocaml (rex_parse grepre) in
  let ic = if fname = "-" then stdin else open_in fname in
      let lzline = lzlines ic in 
      let lzmatch = lzmatches (Str.regexp s) lnums invert lzline in
      let rec helper found lzmatch = match lzmatch with
        | Nil -> close_in ic; found
        | Lcons(h,t) -> print_endline h; helper true (Lazy.force t)
      in helper false lzmatch


