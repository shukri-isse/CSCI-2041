# Homework 4:  Grepping conclusion
*CSci 2041: Advanced Programming Principles, Spring 2022 (Section 1)*

**Due:** Friday, April 29 at 11:59pm

In the `hw2041/hw4` directory, you will find files named `rE.ml`, `cGrep.ml`
`camlgrep.ml`, `takelen.md`, and `replen.md`, and several example input files
(and a testing-related program called `simple.ml`). Create a directory named
`hw4` in your personal repository, and copy all of these files to your `hw4`
directory.  Don't forget to run `git add` on both the directory and the files!

**Reminder:** In this class homeworks are a summative activity.  Therefore, unlike lab problems and reading quizzes, you should only submit code that is the result of your own work and should not discuss solutions to this homework with anyone but the course staff. Additionally, course staff can help you with compiler errors and clarifying requirements but will not help you in *solving* the homework problems.

However, you *may* ask clarifying questions about these instructions on `#hw4-questions` in the course Discord server.  **No code should be posted in this channel.**

## Overview: `grep`

One of the most useful terminal programs for a programmer or system
administrator is [`grep`](https://man7.org/linux/man-pages/man1/grep.1.html).
When run in the terminal followed by a regular expression string and a filename,
`grep re f` processes the file `f` one line at a time, printing out any lines
that contain a substring matching the regular expression `re`.  (The application
also supports options like processing an entire folder and its subfolders;
printing out more lines of "context" before and after the matching line;
printing out lines that *don't* match; printing out just the *count* of matching
lines in a file; reading the regular expression from a file; and various
formatting options; we will skip most of these here.)  This is useful in a
number of contexts, such as trying to find all of the calls to a function, or
all of the uses of a variable, in some large multi-file software project, or
looking at debugging logs or information logs from some long-running process, or
trying to find relevant entries in a transaction log or network log.  It is so
commonly used that it is employed as a verb: to "grep" for something is to
search for matches to a pattern.

`grep` uses very similar syntax for its "basic" regular expressions to the Ocaml
regular expression engine (including escaping the `|`,`(`, and `)` operations,
and also `+`, but not `.`, `*`, `[]` or `?`.).  There are, however, two bits of
"syntactic sugar" in `grep` regular expressions that make it "nicer" to use for
programming- and sysadmin-related tasks:

+ `grep` has a few "special" bracket groups that are commonly used in regular
expressions: `\w` matches any "word" character (`[_0-9a-zA-Z]`), `\s` matches a
"whitespace" character (`[ \t]`), `\d` matches a digit (`[0-9]`), and
capitalizing any of these inverts the group (so `\W` matches any "non-word"
character).  (`grep` has been around since the first Unix distributions and thus has many versions; in Linux, `grep` does not support `\d` or `\s` as "basic" regexes, and you need to include the `-P` flag as an argument to `grep` to use them.  BSD unixes like macOS, FreeBSD and OpenBSD *do* support them as basic regexes, and you don't need to use any special flag in those systems.)

+ `grep` supports the "bounded repetition" postfix operator.  if _`r`_ is a
regular expression, then _`r`_`{m,n}` matches *at least* `m` concatenations of
_`r`_ and *at most* `n` concatenations of _`r`_, so for example the regular
expression `[ab]{2,3}` is a synonym for `[ab][ab][ab]?` and matches any string
of two or three `a` or `b` characters.  There are a few other variations of
this: `{,n}` is the same as `{0,n}`; `{n}` is the same as `{n,n}` so *exactly*
`n` concatenations of its argument; and `{m,}` matches `m` or more
concatenations of its argument, so e.g. `[ab]{2,}` is equivalent to
`[ab][ab][ab]*`.

Another useful property of `grep` is that it processes its inputs line-by-line,
so if the "file" it is reading is, e.g. the output of another program, or a
network stream, it can output matches as they are generated or received, rather
than needing to wait for the program to terminate or the stream to finish
downloading.  (In the terminal, the standard output of one program can be fed
into the standard input of another using the "pipe" operator `|`.  To see an
example of this, try compiling the `simple.ml` program included in `hw4` with
`ocamlc -o simple unix.cma simple.ml` then run `./simple | grep "^\(11\)*$" -`
in the terminal.  You will see that as each even-length line of output is
printed by `simple`, it is also printed by `grep`, rather than having to wait 5
minutes for `simple` to finish running.)

## Homework 2: `camlgrep`

In this homework your goal will be to write a terminal application called `camlgrep` that simulates this behavior in ocaml.  When we run `camlgrep` in the terminal with a regular expression and a filename, it will

+ open the file for reading, creating a `string lzlist` that will read the next line in the file each time we force the tail of the list,

+ convert the "grep"-syntax regular expression into an ocaml-syntax regular expression,

+ and iterate through the lazylist, printing out lines that match the regular expression.

+ call `exit 0` if there were no matches, `exit 1` if there was at least one match, and `exit 2` if there were any failures (due to an invalid regexp or file-opening failure), while also printing the reason for the failure on the `stderr` outchannel.

Additionally, `camlgrep` will support three additional features of `grep`:

+ if the command-line option `-n` appears between `camlgrep` and the regular expression, matching lines will have their line number included in the output.

+ if the command-line option `-v` appears between `camlgrep` and the regular expression, only lines that do *not* match will be printed.

+ if the filename is `"-"`, the standard input will be used as the input file.

Here are some example outputs we should see when running `camlgrep` in the terminal:

```sh
% ./camlgrep -n "\d\d" umnwiki.txt
4:Heights, a suburb of St. Paul, approximately 3 miles (4.8 km) apart.[10] The
7:with 51,327 students in 2019–20.[11] It is the flagship institution of the
8:University of Minnesota System, and is organized into 19 colleges, schools, and
12:territorial university in 1851, seven years before Minnesota became a state.
14:research activity.[12] Minnesota is a member of the Association of American
15:Universities and is ranked 17th in research activity, with $954 million in
16:research and development expenditures in the fiscal year 2018.[13] In 2001, the
19:comparable to that of the Ivy League.[14]
21:University of Minnesota faculty, alumni, and researchers have won 26 Nobel
22:Prizes[15] and three Pulitzer Prizes.[16] Among its alumni, the university
23:counts 25 Rhodes Scholars,[17] seven Marshall Scholars,[18] 20 Truman
24:Scholars,[19] and 127 Fulbright recipients.[20] The university also has
28:Medicine, and National Academy of Engineering.[21] Notable University of
30:Humphrey and Walter Mondale, and Bob Dylan, who received the 2016 Nobel Prize in
31:Literature.[22]
33:The Minnesota Golden Gophers compete in 21 intercollegiate sports in the NCAA
34:Division I Big Ten Conference and have won 29 national championships.[23] As of
35:2021, Minnesotas current and former students have won a total of 76 Olympic
36:medals.[24]
```

```sh
% ./camlgrep -v "[Uu]niversity\|Gopher\|Minnesota" umnwiki.txt
Heights, a suburb of St. Paul, approximately 3 miles (4.8 km) apart.[10] The
system and has the ninth-largest main campus student body in the United States,
with 51,327 students in 2019–20.[11] It is the flagship institution of the
other major academic units.

Universities and is ranked 17th in research activity, with $954 million in
research and development expenditures in the fiscal year 2018.[13] In 2001, the
includes publicly funded universities thought to provide a quality of education
comparable to that of the Ivy League.[14]

counts 25 Rhodes Scholars,[17] seven Marshall Scholars,[18] 20 Truman
Guggenheim Fellowship, Carnegie Fellowship, and MacArthur Fellowship holders, as
well as past and present graduates and faculty belonging to the American Academy
of Arts and Sciences, National Academy of Sciences, National Academy of
Humphrey and Walter Mondale, and Bob Dylan, who received the 2016 Nobel Prize in
Literature.[22]

Division I Big Ten Conference and have won 29 national championships.[23] As of
medals.[24]
```

```sh
% ./camlgrep -n -v "\w" umnwiki.txt
10:
20:
32:
```

```sh
% ocamlc -o simple unix.cma simple.ml
% ./simple | ./camlgrep '^\(\d\{4\})\{2,10\}$' -
11111111
111111111111
1111111111111111
11111111111111111111
111111111111111111111111
1111111111111111111111111111
11111111111111111111111111111111
111111111111111111111111111111111111
1111111111111111111111111111111111111111
```

(In this last example, you should see the lines appear roughly every 2 seconds, but the application won't terminate for about 5 minutes, since `simple.ml` prints 600 lines at a rate of 2 lines/second.)

## A Tour of the provided files

OK, so now that we know what we're trying to make, we're ready to take a look at the code.
Looking at the files in the `hw4` directory, we see that there are 5 ocaml files:

* `rE.mli` and `rE.ml` - the interface and implementation of a parser for
grep-syntax regular expressions.  You don't need to do modify these files at
all, although you should compile `rE.ml` with `ocamlc -c rE.mli rE.ml`.  As
explained below, `camlgrep` will translate grep-syntax regular expressions into
Ocaml-syntax regular expressions, and the addition of the bounded-repetition
operator requires parsing these expressions into syntax trees.  You should make
sure you understand the `RE.t` type, because you will be writing a function to
convert them back into ocaml-syntax regular expressions.

* `cGrep.ml` - this is where you'll do all the coding for this homework.  It
defines the `'a lzlist` type and includes some functions we'll use to test the
functions you write.  We'll fill in the functions `lzlines`, `lzmatches`,
`to_ocaml`, and `print_matches`, as described below.

* `camlgrep.ml` - this collects the command-line arguments to `camlgrep`, calls
the functions you'll define in `cGrep.ml`, and catches any `Failure` or
`Sys_error` exceptions raised by these functions.

* `simple.ml` - this is a separate program for illustrating the "line-by-line" processing described above.  You don't need to alter this program at all.

In addition, there are two markdown file, `takelen.md` and `replen.md`, in which you'll write some induction proofs about the code in `cGrep.ml`, as described below.

**Compiling** Compiling the application will require a little bit of care, because some of the files depend on others:  

```sh
% ocamlc -o camlgrep str.cma rE.mli rE.ml cGrep.ml camlgrep.ml
```

In addition, when testing functions from `cGrep.ml` in utop, you will want to `#load "rE.cmo";;` and if you are cut-and-pasting instead of using `#use` you should make sure to `open RE;;` in utop so that the `RE.t` constructors are in the same namespace as your function definitions.

**NOTE: If an error in one function causes your submission to fail to compile, _all_ of your automated testing scores for that file will be 0.  (This is how auto-grading works: it compiles and runs your code)  If you cannot implement one of these functions in a way that will compile, leave the original version in place and put your best attempt in a comment.**

## Missing Functions

### 1. `lzlines` (10 points)

We'll start with a fairly short function, `lzlines : in_channel -> string lzlist`.  This function should take as input an `in_channel`, and return a lazy list whose elements will eventually consist of all the lines in the file.  Some example evaluations:

+ `lztake 3 (lzlines (open_in "four.txt"))` should evaluate to `["1";"two";"THREE"]`.
+ `lzlength (lzlines (open_in "/usr/share/dict/words"))` should evaluate to `102401` on a CSELabs linux machine.  (on my macbook it evaluates to `235886`; apparently macs know more words than linux boxes)
+ `lztake 5 (lzlines (open_in "three.text"))` should evaluate to `["3";"2";"1"]`.
+ `lzlength (lzlines (open_in "/dev/null"))` should evaluate to `0`.

### 2. `lzmatches` (15 points)

Next we tackle the "second-hardest" function for this homework, `lzmatches :
Str.regexp -> bool -> bool -> string lzlist -> string lzlist`.  `lzmatches re ln
inv ll` should return a `string lzlist` that has all the elements of `ll` that
have a substring that matches the `Str.regexp` `re` (searching forward from
index 0).  There are two behavior-modifying parameters: if `ln` is true, then
every string in the output lazy list should have its 1-based index in the
original list (its "_l_ine _n_umber"), followed a colon ":" added to the start;
and if `inv` is true, the output should include only strings from `ll` that do
*not* match `re`.  Some example evaluations:

+ `lztake 3 (lzmatches (Str.regexp "[ab]") false false (lz_of_list ["cab"; "123"; "aaa"]))` should evaluate to `["cab"; "aaa"]`
+ `lztake 3 (lzmatches (Str.regexp "[ab]") true false (lz_of_list ["cab"; "123"; "aaa"]))` should evaluate to `["1:cab";"3:aaa"]`
+ `lztake 3 (lzmatches (Str.regexp "[ab]") false true (lz_of_list ["cab"; "123"; "aaa"]))` should evaluate to `["123"]`
+ `lztake 4 (lzmatches (Str.regexp ".*") true false (lz_of_list ["this";"is";"my";"list";"now"]))`
should evaluate to `["1:this";"2:is";"3:my";"4:list"]`
+ `lztake 4 (lzmatches (Str.regexp ".*") true true (lz_of_list ["this";"is";"my";"list";"now"]))` should evaluate to `[]`.
+ `lztake 4 (lzmatches (Str.regexp "..+") true false (lz_of_list ["this";"is";"a";"list";"now"]))` should evaluate to `["1:this"; "2:is"; "4:list"; "5:now"]`.


### 3. `to_ocaml` (25 points)

The "hardest" function to write is the function `to_ocaml : RE.t -> string`.
This function will be used to finish the conversion from grep regular
expressions to ocaml regular expressions.  You might be thinking: "what's so
hard about that? We can just scan through the string and replace `\d` with
`[0-9]`, `\s` with `[ \t]`..." and you're right: most of the job could be
accomplished that way.  The problem comes with the bounded repetition operator
`\{m,n\}`: if it is applied to a regular expression that also contains
repetitions or choices, how do we figure out what to repeat?  To solve this
problem, the file [`rE.ml`](./rE.ml) contains a complete parser for grep regular
expressions: it will convert them to regular expression trees of the type
`RE.t`.  The purpose of `to_ocaml` is to convert those trees back to strings
that the `Str.regexp` parser will understand.  (Note: the `cGrep.ml` file uses
`open RE` to  make the constructor names and the function `parse_rex` part of
its namespace.  To test code you write for this problem in utop, you'll need to
`#load "rE.cmo";;` and if you aren't testing with `#use "cGrep.ml";;` then you
should also `open RE;;` in utop.)

For many of the `RE.t` constructors the conversion is pretty simple:
- to convert a `Char` to a string, just call `String.make 1` on its argument (unless the character must be escaped in an ocaml regexp; see the `Str` manual page for a list)
- to convert a `Choice` into a string, we recursively convert the choices and then concatenate them together with the string `"\|"`;
- a `Bracket` just needs its argument enclosed in brackets, since the grep and ocaml syntax for brackets is identical
- Special `Class` regexes are simple: `Wild` is `"."`, `StL` is `"^"`, `EoL` is `"$"`, and the new cases (`Digit`/`NotDigit`, `Space`/`NotSpace`, and `Word`/`NotWord`) are explained in the introduction.
- to convert a `Concat` we also recursively convert the subexpressions and then concatenate these together.  However, any `Choice` subexpressions need to be parenthesized.
- The postfix repetition operators `Star`, `Plus`, and `Opt` should have their arguments recursively converted, and then the correct operator appended (`*`,`+`, or `?`); but if the argument uses an operation with lower precedence than repetition, it will need to be parenthesized.  (Just as if we wanted to square `x+y` we would write `(x+y)²` in an arithmetic expression.)
- Bounded repetition, as represented by the `Rep` constructor, is also a postfix operation, but because ocaml regexps don't natively support it, we'll need to be explicit: if the bounds are, say, {m,n} then we'll want `m` copies of the argument, plus `n-m` options of the argument; if there is no upper bound, we follow `m` copies of the argument with a single, starred copy.

Some example evaluations:
+ `to_ocaml (Concat [Char 'a'; Char 'b'; Class Word; Star(Char 'a'); Class EoL])` should evaluate to `"ab[_0-9A-Za-z]a*$"`
+ `to_ocaml (Concat [Class StL; Char '.'; Choice [Class Wild; Class Digit]; Opt (Concat [Char '['; Char ']'])])` should evaluate to (the escaped version of)`{|^\.\(.\|[0-9]\)\(\[\]\)?|}`
+ `to_ocaml (Choice [Concat [Plus (Class NotSpace); Char 'a']; Char 'b'; Bracket "A-Z"])` should evaluate to `"[^ \t]+a\\|b\\|[A-Z]"`
+ `to_ocaml (Rep (0, None, Char 'a'))` should evaluate to `"a*"`
+ `to_ocaml (Rep (1, Some 3, Char 'b'))` should evaluate to `"bb?b?"`
+ `to_ocaml (Rep (1, Some 3, Bracket "bc"))` should evaluate to `"[bc][bc]?[bc]?"`
+ `to_ocaml (Rep (2, Some 2, Char 'c'))` should evaluate to `"cc"`
+ `to_ocaml (Rep (2, Some 1, Char 'd'))` should raise `Failure "invalid repetition count(s)"`.
+ `to_ocaml (Rep (1, Some 1, Concat [Char 'e'; Char 'e']))` should evaluate to (the escaped version of) `{|\(ee\)|}`.

Note: you may find it helpful to structure this function as a series of calls to (mutually recursive) helper functions that handle the individual cases, similarly to how the `parse_rex` function in `rE.ml` or the `eval` or `typeof` functions in Labs 8 and 9 or the `_parser` function in Homework 3 were structured.

### 4. `printmatches` (10 points)

The function `printmatches : string -> string -> bool -> bool -> bool` puts all of the pieces together: `printmatches s f lnum inv` should convert the "grep regex" `s` into an ocaml `Str.regexp` by calling `to_ocaml`, then open the file `f` for reading (or use `stdin` if `f` is `"-"`), use `lzlines` and `lzmatches` to get a `string lzlist` of lines to print out, print them to the standard output, and close the file, returning `true` if at least one matching line was found, and `false` otherwise.  Here are a few example evaluations:

+ `printmatches ".*" "/dev/null" true true` should print nothing to the terminal and return false.

+ `printmatches "^.\\{23\\}$" "/usr/share/dict/words" true false` should print the line `42702:electroencephalograph's` to the terminal and return `true` (on a CSE linux machine; on my macbook there are 17 words matching this pattern in `/usr/share/dict/words`)

+ `printmatches {|\w\+\s\d\+|} "umnwiki.txt" true false` should print the lines:
```
4:Heights, a suburb of St. Paul, approximately 3 miles (4.8 km) apart.[10] The
7:with 51,327 students in 2019–20.[11] It is the flagship institution of the
8:University of Minnesota System, and is organized into 19 colleges, schools, and
12:territorial university in 1851, seven years before Minnesota became a state.
15:Universities and is ranked 17th in research activity, with $954 million in
16:research and development expenditures in the fiscal year 2018.[13] In 2001, the
21:University of Minnesota faculty, alumni, and researchers have won 26 Nobel
23:counts 25 Rhodes Scholars,[17] seven Marshall Scholars,[18] 20 Truman
24:Scholars,[19] and 127 Fulbright recipients.[20] The university also has
30:Humphrey and Walter Mondale, and Bob Dylan, who received the 2016 Nobel Prize in
33:The Minnesota Golden Gophers compete in 21 intercollegiate sports in the NCAA
34:Division I Big Ten Conference and have won 29 national championships.[23] As of
35:2021, Minnesotas current and former students have won a total of 76 Olympic
```
to the terminal and evaluate to `true`.

Once you have finished `printmatches`, your application should be ready to run.  You can compile it with

```sh
% ocamlc -o camlgrep str.cma rE.mli rE.ml cGrep.ml camlgrep.ml
```
and then you can test in the terminal with the examples given at the start of the document.

## Proofs

Now that we have a "real" application to consider, let's put our induction
skills to work by proving a pair of theorems about the code in the application.
For both of these questions, you should follow a format similar to the lab 11 proof
problems: include a section with the relevant code at the top of the markdown
file, then state the property you will prove, prove the base case, state the
inductive hypothesis you will assume and the inductive conclusion it is your
goal to prove, and justify all of the equivalences/substitutions you make in the
steps of your proof.

As in the lab proofs, your files can be in "Github-Flavored Markdown", so if you
want to use mathematical symbols, you can use their
[HTML character entities](http://dev.w3.org/html5/html-author/charref).

Note: the gitbot cannot offer feedback on your solutions to these problems.

### 5. `takelen` (20 points)

Your solution for this problem should go in the file `takelen.md`.  We'll be
working with the `lztake` and `lz_of_list` functions defined in `cGrep.ml`,
along with the (by now standard) `length` function defined by:

```ocaml
let rec length = function [] -> 0
| _::t -> 1 + (length t)
```

Let's prove that if we convert a `'a list` to a `'a lazylist`, then `lztake` as many elements as there were in the original list, we get the original list back, that is:

> ∀ `l : 'a list`, `(lztake (length l) (lz_of_list l)) ≡ l`.

You may find it useful to have the **[eval of `Lazy.force`]** rule:  

> ∀x, `Lazy.force (lazy (x)) ≡ x`.

### 6. `replen` (20 points)

Your solution to this problem should be recorded in the file `replen.md`.  We'll now let you prove a statement about a function that you have defined, specifically about how your `to_ocaml` function works on `Rep` constructors:

> ∀ n : ℕ, ∀ r : `RE.t`, `String.length (to_ocaml (Rep(r,0,Some n)) ≡ n * String.length (to_ocaml (Opt r))`

You may assume the `String.length` identity `String.length (a^b) ≡ (String.length a) + (String.length b)`.  Be sure to include all of the relevant code from your definition of `to_ocaml` in the file so that the grader can verify all of your justifications.

## Other considerations

In addition to satisfying the functional specifications given above, your code
should be readable, with comments that explain what you're trying to accomplish.
It must compile with no errors using the command

`ocamlc -o camlgrep str.cma rE.mli rE.ml cGrep.ml camlgrep.ml`

Solutions that pay careful attention to resource use (files, stack space,
running time) and code reuse are worth more than solutions that do not have
these properties.

## Submission instructions and extension requests.

Once you are satisfied with the status of your submission in github, you can upload
the files `cGrep.ml`, `takelen.md`, and `replen.md` to the "Homework 4" assignment on
[Gradescope](https://www.gradescope.com/courses/342332/assignments/1912404).  
We will run additional correctness testing to the basic feedback tests described
here, manually grade your proofs, and provide some manual feedback on the
efficiency, readability, structure and comments of your code, which will be
accessible in Gradescope once all submissions have been graded. Your proofs will
be graded both for clarity (what are you trying to prove? why? Can we understand
the steps your proof is taking? are you using the proper notation and names for
properties and steps?) and correctness (does your proof (correctly) justify the
steps it takes?  Have you correctly stated and covered all of the possible
cases?  Are there no missing steps or logical gaps that need to be addressed?)

**Extension Requests**: Keep in mind that every student is allowed to request up
to 6 24-hour deadline extensions for the four homeworks this semester, but no
more than 4 may be used on any single homework.  To request an extension for
this homework, please use [this form](https://forms.gle/CAgKxQZURZUob43b9)
by the submission deadline on Friday, 4/29.
