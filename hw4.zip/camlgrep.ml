(* camlgrep.ml - OCaml grep implementation for CSCI 2041 HW 4 *)

let args = Array.to_list Sys.argv
let (invert,lnums,pattern,fname) = match (List.tl args) with
| "-v"::"-n"::[p;f] | "-n"::"-v"::[p;f] -> (true,true,p,f)
| "-v"::[p;f] -> (true,false,p,f)
| "-n"::[p;f] -> (false,true,p,f)
| [p;f] -> (false,false,p,f)
| _ -> exit 2 (* wrong number of arguments *)

let result = try CGrep.printmatches pattern fname lnums invert with Failure s | Sys_error s -> let () = Printf.fprintf stderr "camlgrep: %s\n" s in exit 2

let () = if result then (exit 1) else (exit 0)
