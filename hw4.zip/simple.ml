let rec ploop i j = if i = j then exit 0 else
let () = print_endline (String.make i '1') in
let () = Unix.sleepf 0.5 in ploop (i+1) j

let () = ploop 0 600
