(* program.ml - a data structure for representing programs *)
exception TypeError of string
exception RuntimeError of string
let rt_err s = raise (RuntimeError s)
let type_err s = raise (TypeError s)

(*Added a new constructor to expr for a Readint expression*)
(*Added a new constructor for a list literal, ListC with the argumen type int list*)
(*Added a new constructor for the cons operation, Cons with a pair of subexpressions as arguments*)
(*Added new constructors for the head and tail operations, Head and Tail with a single subexpression as an argument each*)
(*Added a new constructor to expr, Funrec, with five arguments: a string representing the function name, a string representing the argument name, the type of return value, the type of argument, & expr repesenting the body of the funcion*)
(*Added a new constructor to result, ClosureRec, with four arguments: the expression the body of the function, a string representing the function name, a string representing the argument name, & the state/environment*)
type expr =
  IntC of int | BoolC of bool
  | Funrec of string * string * expType * expType * expr
  | Readint
  | ListC of int list
  | Cons of expr * expr
  | Head of expr
  | Tail of expr
  | Add of expr * expr
  | Sub of expr * expr
  | Mul of expr * expr
  | Div of expr * expr
  | If of expr * expr * expr
  | Let of string * expr * expr
  | Name of string
  | And of expr * expr
  | Or of expr * expr
  | Not of expr
  | Lt of expr * expr
  | Eq of expr * expr
  | Gt of expr * expr
  | Seq of expr list
  | While of expr * expr
  | Set of string * expr
  | Fun of string * expType * expr
  | Apply of expr * expr
  | Print of expr
 and expType = IntT | BoolT | UnitT | FunT of expType * expType | ReadintT | ListT

(* Type to represent a state of the program, e.g. the current stack of variables and the values they are bound to *)
type stType = (string * result) list
 (* Type to represent a value in the program *)
 (*Added a new constructor to the result type, ListR, with an argument of type int list*)
 and result = IntR of int | BoolR of bool | UnitR | Closure of expr*string*stType | ReadintR | ListR of int list | ClosureRec of expr * string * string * stType

(* Searches the stack and updates the most recent binding with the new value *)
let rec assign name value state =
  match state with
  | [] -> rt_err "assign to unbound name"
  | (n,v)::t when n=name -> (name,value)::t
  | b::t -> b::(assign name value t)

(* pop a variable binding off the stack *)
let rec pop name state =
  match state with
  | [] -> rt_err "popping unbound name: internal error"
  | (n,v)::t when n=name -> t
  | b::t -> b::(pop name t)

(* evaluate an expression: return the value and the new program state *)
let rec eval exp state = match exp with
(*Modified the evaluation function to read an integer whenever it encounters a Readint expression 
using the Ocaml function read_int : unit -> int to read an integer from the standard input w/o changing the state;*)
(*Modified the expType type to include a new constructor, ListT, that will represent the type of list values. ListT won't have any arguments*)
(*Modified typeof to infer the correct type of a ListC constructor, using the type judgement => ListC _ : ListT*)
(*Modified typeof to infer the correct type of a Head expression, using the type judgement e : ListT => Head e : Int. (raise TypeError "Head". Otherwise raises TypeError "Head"*)
(*Modified typeof to infer the correct type of a Tail expression. Otherwises raises TypeError "Tail"*)
(*Modified typeof to infer the correct type of a Cons expression. Otherwises raises TypeError "Cons"*)
(*Added a sub-case for ListT in the case that type-checks Eq expressions*)
(*Addded a case to handle ListC, wrapping the list literal in a ListR constructor.*)
(*Added cases to handle Tail and Head, which recursively evaluate their subexpression, extract the resulting list, and wrap the head or tail in the appropriate result constructor.*)
(*Added a case to handle Cons, which recursively evaluates its first argument, then second argument, then unwraps the values and returns a ListR value and the state resulting from the evaluation of the second argument*)
(*Added a sub-case to the case that evaluates Print constructors to handle ListR values. Printing a list should result in something like "[1 2 3]"*)
(*Added a clause to eval for the Funrec constructor - similar to Fun, except that Funrec returns a ClosureRec result that captures the function name as well as the argument name from the Funrec constructor.*)
(*Added a case to the Print clause in eval for ClosureRec results: let's have the intepreter print "<funrec>" when printing a recursiv closure*)
(*Extended the function evalFunc with an explicit match statement to accomadate both Closure and ClosureRec*)
  | Funrec (funcname,argname,_,_,body) -> (ClosureRec (body,funcname,argname,state), state) (* "Captures" current environment at definition.*)
  | Head e -> let (ListR r, st') = eval e state in (IntR (List.hd r), st')
  | Tail e -> let (ListR r, st') = eval e state in (ListR (List.tl r), st')
  | ListC l -> (ListR l, state)
  | Cons (e1, e2) ->  let (IntR r1, st') = eval e1 state in let (ListR r2, st'2) = eval e2 st' in (ListR (r1::r2), st'2)
  | Readint -> ( IntR (read_int()), state) 
  | IntC n -> (IntR n, state)
  | BoolC b -> (BoolR b, state)
  | Add (e1,e2) -> evalInt (+) e1 e2 state
  | Mul (e1,e2) -> evalInt ( * ) e1 e2 state
  | Sub (e1,e2) -> evalInt (-) e1 e2 state
  | Div (e1,e2) -> evalInt (/) e1 e2 state
  | If (cond,thn,els) -> evalIf cond thn els state
  | Let (nm,vl,exp') -> evalLet nm vl exp' state
  | Name nm -> (List.assoc nm state, state)
  | And (e1,e2) -> evalBool (&&) e1 e2 state
  | Or (e1,e2) -> evalBool (||) e1 e2 state
  | Not e -> let (BoolR b, st') = eval e state in (BoolR (not b), st')
  | Lt (e1, e2) -> evalComp (<) e1 e2 state
  | Eq (e1, e2) -> evalComp (=) e1 e2 state
  | Gt (e1, e2) -> evalComp (>) e1 e2 state
  | Seq elist -> evalSeq elist state
  | While (cond,body) -> evalWhile cond body state
  | Set (name, e) -> let (vl, st') = eval e state in (UnitR, assign name vl st')
  | Fun (argname,_,body) -> (Closure (body,argname,state), state) (* "Captures" current environment at definition. *)
  | Apply (f,e) -> evalFunc f e state
  | Print e -> let (r,st') = eval e state in
         let () = match r with
     | ListR l -> 
          print_string ("[" ^ (String.concat " " (List.map string_of_int l)) ^ "]")
     | ClosureRec (e, funcname, argname, state) -> print_string  "<funrec>"
		 | UnitR -> print_string "()"
		 | IntR i -> print_int i
		 | BoolR b -> print_string (if b then "True" else "False")
		 | Closure _ -> print_string "<fun>" in
	       let () = print_string "\n" in
	       let () = flush stdout in
	       (UnitR, st')
and evalInt f e1 e2 state =
  let (IntR i1, st1) = eval e1 state in
  let (IntR i2, st2) = eval e2 st1 in
  IntR (f i1 i2), st2
and evalIf cond thn els state =
  let (BoolR b, st') = eval cond state in
  if b then eval thn st' else eval els st'
and evalLet name vl exp state =
  let (r, st') = eval vl state in
  let (r', st'') = eval exp ((name,r)::st') in
  (r', pop name st'')
and evalBool f e1 e2 state =
  let (BoolR b1, st1) = eval e1 state in
  let (BoolR b2, st2) = eval e2 st1 in
  BoolR (f b1 b2), st2
and evalComp cmp e1 e2 state =
  let (r1, st1) = eval e1 state in
  let (r2, st2) = eval e2 st1 in
  (BoolR (cmp r1 r2), st2)
and evalSeq elist st = match elist with (* Whee, tail recursion. *)
  | [] -> (UnitR, st)
  | e::[] -> eval e st
  | e::t -> let (_, st') = eval e st in
	    evalSeq t st'
and evalWhile cond body st = (* Note the tail recursion. An infinite while loop won't blow the stack *)
  let (BoolR b, st') = eval cond st in
  if (not b) then (UnitR, st') else
    let (_, st'') = eval body st' in
    evalWhile cond body st''
and evalFunc f arg state = (* Note: we need to evaluate the function with environment at time of definition *)
(*body, argname, def_st'*)
  let (c, st') = eval f state in
  let (argval, st'') = eval arg st' in (* but computing its argument could change state at call site *)
  let (argname, def_st, body) = (match c with (**)
  | Closure (body,argname,def_st) -> (argname, def_st, body)
  | ClosureRec (e, fname, argname, def_st)-> (argname, (fname,ClosureRec(e, fname, argname, def_st))::def_st, e)) in
  let (result, _) = eval body ((argname,argval)::def_st) in
  (result, st'') (* So state after call must be the state after argument computation *)

(* Type checking/inference: Figure out type for an expression.  Fail if the expression is not well-typed.*)
(*Added a new type-checking rule to typeof to infer the correct type of a Readint constructor in an expression, using the type judgement => Readint : IntT *)
(*Added a clause to typeof to handle checking the type of a Funrec expression, using the typing rule (f : t1 -> t2, x : t1) |- e : t2 => Funrec(f,x,t2,t1,e) : t1 -> t2*)
let rec typeof exp env = match exp with
  | Funrec (funcname, argname, type_val, type_arg, e)-> if (typeof e ((funcname,FunT (type_arg, type_val))::(argname,type_arg)::env)) =  type_val  then FunT (type_arg, type_val) else type_err "Type Error" 
  | Head e -> if (typeof e env) = ListT then IntT else type_err "Head" 
  | Tail e -> if (typeof e env) = ListT then ListT else type_err "Tail"
  | Cons (e1, e2) -> 
    ( match (typeof e1 env, typeof e2 env) with
       | (IntT, ListT) -> ListT
       | _ -> type_err "Cons")
  | ListC _ -> ListT
  | Readint -> IntT
  | IntC _ -> IntT
  | BoolC _ -> BoolT
  | Add (e1,e2) | Sub (e1,e2) | Mul (e1,e2)
  | Div (e1,e2) ->
     ( match (typeof e1 env, typeof e2 env) with
       | (IntT,IntT) -> IntT
       | _ -> type_err "Arithmetic on non-integer arguments")
  | And (e1,e2)
  | Or (e1,e2) ->
     ( match (typeof e1 env, typeof e2 env) with
       | (BoolT,BoolT) -> BoolT
       | _ -> type_err "Boolean operation on non-Bool arguments")
  | Not e -> if (typeof e env) = BoolT then BoolT else type_err "Not of non-Boolean"
  | Lt (e1,e2)
  | Gt (e1,e2) ->
     ( match (typeof e1 env, typeof e2 env) with
       | (IntT,IntT) -> BoolT
       | _ -> type_err "Comparison of non-integer values" )
  | Eq (e1,e2) ->
     ( match (typeof e1 env, typeof e2 env) with
       | (IntT,IntT) | (BoolT,BoolT) | (UnitT,UnitT) | (ListT, ListT) -> BoolT 
       | _ -> type_err "Equality test on incompatible values" )
  | If (cond,thn,els) ->
     if not ((typeof cond env) = BoolT) then type_err "If on non-boolean condition" else
       let (t1,t2) = (typeof thn env, typeof els env) in
       if (t1 = t2) then t1 else type_err "Different types for then/else branches"
  | Name name -> (try List.assoc name env with Not_found -> type_err ("Unbound variable "^name))
  | Let (name,vl,e) ->
     let t = typeof vl env in
     typeof e ((name,t)::env)
  | Seq elist -> seqType elist env
  | While (c,body) ->
     ( match (typeof c env, typeof body env) with
       | (BoolT, _) -> UnitT
       | _ -> type_err "Non-boolean condition for while")
  | Set (name, e) -> if (typeof (Name name) env) = (typeof e env) then UnitT else type_err "assign type mismatch"
  | Fun (argname, argType, body) ->
     let resType = typeof body ((argname,argType)::env) in
     FunT (argType,resType)
     (* in *)
  | Apply (e1,e2) ->
     ( match (typeof e1 env) with
       | FunT (argtype, restype) -> if (typeof e2 env) = argtype then restype
				       else type_err "incompatible function argument"
       | _ -> type_err "Apply of non-function value")
  | Print e -> let _ = typeof e env in UnitT
and seqType el env = match el with
  | [] -> UnitT
  | [e] -> typeof e env
  | e::rest -> let _ = typeof e env in seqType rest env
