(* a data type representing expressions.  Fill in: *)

type formula = Add of formula * formula | Sub of formula * formula | Mult of formula * formula | Div of formula * formula | Max of formula * formula | Min of formula * formula | Const of float | Rank | Aggr														     

let make_add f1 f2 = Add(f1,f2)
let make_sub f1 f2 = Sub(f1,f2)
let make_mul f1 f2 = Mult(f1,f2)
let make_div f1 f2 = Div(f1,f2)
let make_max f1 f2 = Max(f1,f2)
let make_min f1 f2 = Min(f1,f2)
let make_float f = Const f
let make_rank() = Rank
let make_aggr() = Aggr

(* let rec compute (f : formula) (rank : float) (agg : float) *)
 let rec compute f rank agg =  match f with
  | Add(f1,f2) -> (compute f1 rank agg) +. (compute f2 rank agg)
  | Sub(f1,f2) -> (compute f1 rank agg) -. (compute f2 rank agg)
  | Mult(f1,f2) -> (compute f1 rank agg) *. (compute f2 rank agg)
  | Div(f1,f2) -> (compute f1 rank agg) /. (compute f2 rank agg)
  | Max(f1,f2) -> if f1 > f2 then (compute f1 rank agg) else (compute f2 rank agg)
  | Min(f1,f2) -> if f1 < f2 then (compute f1 rank agg) else (compute f2 rank agg)
  | Const f -> f
  | Rank -> rank
  | Aggr -> agg
  

(* let rec rank (c : 'a) (default : float) (ls : 'a list) = default *)
let rank c d ls =
let rec rank_helper c d ls acc= match ls with
    | [] -> d
    | h::t -> if h=c then (acc +. 1.) else rank_helper c d t (acc+.1.)
in rank_helper c d ls 0. 

(* let rec score (c : 'a) (agg : float, the initial score) (f : formula) (n : float) (ballots : 'a list list) = agg *)
let rec score c agg f n ballots = match ballots with (*finds the rank of c*)
    | []-> agg
    | h::t -> let r = (rank c n h) in score c (compute f r agg) f n t (*updates the score*)

(* let score_all (cs : 'a list) (init : float) (f : formula) (ballots : 'a list list) : ('a * float) list = [] *)
(*for each candidate compute score, returns list of pairs (h,score)*) (*helper func w/ list of candidates and return list*)
 (* let rec score_all cs init f ballots = match cs with
    | []-> []
    | h::t -> let s = (score cs init f ballots) in score_all cs s f t
    *)
