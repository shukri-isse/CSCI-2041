(* free code: don't worry, you aren't meant to understand this function yet. *)
let get_ballot_lines bfile = 
  let ic = open_in bfile in
  let rec get_bl acc = 
    match (try Some (input_line ic) with End_of_file -> None) with
    None -> List.rev acc
    | Some l -> get_bl (l::acc) in
  let ballot_lines = get_bl [] in
  let () = close_in ic in ballot_lines

(* Given a list of comma-delimited "ballots" return a list of lists where each
   element is the list of comma-delimited options.  
 *)
(*let ballots_from_lines (blines : string list) : string list list = [] *) 
let rec ballots_from_lines blines = match blines with
  | [] -> []
  | h::t -> let x = (String.split_on_char ',' h) in if x = [""] then []::ballots_from_lines t else x::ballots_from_lines t

(* Identify the index of the first ballot that has a candidate not in the candidate list *)
(* Return None if all ballots are legal. *)
(* let first_error (cs : 'a list) (ballots : 'a list list) : int option = None *)
(*List.mem c lst returns true if c in list, iterate thru every candidate, use list.mem of candidate and ballots list*)
  (*let first_error cs ballots =
  let rec first_helper2 cs ballot = match ballot with
      |h::t -> if List.mem cs ballot = true then true else false
    in let rec first_error_helper cs ballots idx = match (cs, ballots) with
      |([], _) -> None
      |(_,[]) -> None
      |(cs,h::t)-> if first_helper2 cs h= false then Some idx else first_error_helper cs t (idx+1)
  in first_error_helper cs ballots 0
  *)

(* Given a list of (candidate,score) pairs, compute the String length of the longest candidate *)
(* let max_len (sl : (string * float) list) = 0 *)

let rec max_len_helper sl n = match sl with
  | [] -> n
  | (x,y)::t -> if String.length x > n then (max_len_helper t (String.length x)) else (max_len_helper t n ) 
let max_len sl =
 max_len_helper sl 0

(* Pad the string s (with spaces) to length at least l *)
(* let pad (l : int) s = s *)

let rec pad l s = 
if String.length s = l then s else if String.length s > l then s else if l<=0 then s else pad (l-1) s^" "
(* free code: prints the list of rankings out *)

let print_rankings sl = 
  let padlen = max (String.length "Candidate") (max_len sl) in
  let () = print_endline ((pad padlen "Candidate") ^ " \t Score") in
  let () = print_endline ((String.make padlen '-') ^ " \t -----") in
  let rec p_loop = function [] -> () 
  | (c,s)::t -> let () = print_endline ((pad padlen c) ^ " \t " ^ (string_of_float s)) in p_loop t
in p_loop sl 
